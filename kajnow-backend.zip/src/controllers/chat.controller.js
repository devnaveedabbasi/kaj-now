import Job from '../models/job.model.js';
import Message from '../models/chat.model.js';
import User from '../models/User.model.js';
import { ApiError } from '../utils/errorHandler.js';
import { ApiResponse } from '../utils/apiResponse.js';

// ─────────────────────────────────────────────────────────────
// GET /api/chat/history/:jobId
// Both customer & provider can call this
// ─────────────────────────────────────────────────────────────
export async function getChatHistory(req, res) {
  try {
    const { jobId } = req.params;
    const userId = req.user._id;
    const userRole = req.user.role; // 'customer' or 'provider'

    // Verify this user is part of this job
    let job;
    if (userRole === 'customer') {
      job = await Job.findOne({ _id: jobId, customer: userId });
    } else if (userRole === 'provider') {
      // Provider model ka userId use karo
      job = await Job.findOne({ _id: jobId, provider: req.provider._id });
    }

    if (!job) {
      throw new ApiError(404, 'Job not found or access denied');
    }

    const messages = await Message.find({ jobId })
      .sort({ createdAt: 1 })
      .limit(200)
      .lean();

    // Mark incoming messages as read
    await Message.updateMany(
      { jobId, receiverId: userId, isRead: false },
      { isRead: true, readAt: new Date() }
    );

    return res.status(200).json(
      new ApiResponse(200, messages, 'Chat history fetched')
    );
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(500, 'Failed to fetch chat history');
  }
}

// ─────────────────────────────────────────────────────────────
// GET /api/chat/unread/:jobId
// Unread message count for badge on booking list
// ─────────────────────────────────────────────────────────────
export async function getUnreadCount(req, res) {
  try {
    const { jobId } = req.params;
    const userId = req.user._id;

    const count = await Message.countDocuments({
      jobId,
      receiverId: userId,
      isRead: false,
    });

    return res.status(200).json(
      new ApiResponse(200, { unreadCount: count }, 'Unread count fetched')
    );
  } catch (error) {
    throw new ApiError(500, 'Failed to fetch unread count');
  }
}

// ─────────────────────────────────────────────────────────────
// GET /api/chat/all-unread
// Total unread across ALL jobs (for global badge / notification dot)
// ─────────────────────────────────────────────────────────────
export async function getTotalUnread(req, res) {
  try {
    const userId = req.user._id;

    const count = await Message.countDocuments({
      receiverId: userId,
      isRead: false,
    });

    return res.status(200).json(
      new ApiResponse(200, { totalUnread: count }, 'Total unread fetched')
    );
  } catch (error) {
    throw new ApiError(500, 'Failed to fetch total unread');
  }
}
