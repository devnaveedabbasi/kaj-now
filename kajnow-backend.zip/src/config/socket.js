import jwt from 'jsonwebtoken';
import User from '../models/User.model.js';
import Provider from '../models/provider/Provider.model.js';
import Job from '../models/job.model.js';
import Message from '../models/chat.model.js';
import { createNotification } from '../utils/notification.js';

// ─────────────────────────────────────────────────────────────
// Ye map track karega: userId → Set of socketIds
// Ek user ke multiple devices ho sakte hain
// ─────────────────────────────────────────────────────────────
const onlineUsers = new Map();

function addOnlineUser(userId, socketId) {
  if (!onlineUsers.has(userId)) {
    onlineUsers.set(userId, new Set());
  }
  onlineUsers.get(userId).add(socketId);
}

function removeOnlineUser(userId, socketId) {
  if (onlineUsers.has(userId)) {
    onlineUsers.get(userId).delete(socketId);
    if (onlineUsers.get(userId).size === 0) {
      onlineUsers.delete(userId);
    }
  }
}

function isUserOnline(userId) {
  return onlineUsers.has(userId) && onlineUsers.get(userId).size > 0;
}

// ─────────────────────────────────────────────────────────────
// Main socket setup function — app.js mein call hogi
// ─────────────────────────────────────────────────────────────
export function initSocket(io) {

  // ── JWT Auth Middleware for Socket ────────────────────────
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('Unauthorized: No token'));

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      if (!decoded.userId) return next(new Error('Unauthorized: Invalid token'));

      const user = await User.findById(decoded.userId).select('-password');
      if (!user || user.status !== 'approved') {
        return next(new Error('Unauthorized: User not found or not approved'));
      }

      // Provider extra info
      if (user.role === 'provider') {
        const provider = await Provider.findOne({ userId: user._id });
        if (!provider) return next(new Error('Unauthorized: Provider profile not found'));
        socket.provider = provider;
      }

      socket.user = user;
      next();
    } catch (err) {
      next(new Error('Unauthorized: ' + err.message));
    }
  });

  // ── On Connection ─────────────────────────────────────────
  io.on('connection', (socket) => {
    const userId = socket.user._id.toString();
    addOnlineUser(userId, socket.id);

    console.log(`[Socket] Connected: ${socket.user.name} (${socket.user.role}) - ${socket.id}`);

    // Broadcast online status to everyone in this user's job rooms
    socket.broadcast.emit('user_online', { userId });

    // ── Join Chat Room ──────────────────────────────────────
    // Client sends jobId, we make both parties join same room
    socket.on('join_chat', async ({ jobId }) => {
      try {
        // Verify this user belongs to this job
        let job;
        if (socket.user.role === 'customer') {
          job = await Job.findOne({ _id: jobId, customer: socket.user._id });
        } else if (socket.user.role === 'provider') {
          job = await Job.findOne({ _id: jobId, provider: socket.provider._id });
        }

        if (!job) {
          socket.emit('chat_error', { message: 'Job not found or access denied' });
          return;
        }

        const room = `chat_${jobId}`;
        socket.join(room);
        socket.currentJobId = jobId;

        console.log(`[Socket] ${socket.user.name} joined room: ${room}`);

        // Auto mark messages as read when joining
        await Message.updateMany(
          { jobId, receiverId: socket.user._id, isRead: false },
          { isRead: true, readAt: new Date() }
        );

        // Tell the other party that messages are now read (blue ticks)
        socket.to(room).emit('messages_read', {
          jobId,
          readBy: userId,
        });

        socket.emit('joined_chat', { jobId, message: 'Joined chat room' });

      } catch (err) {
        console.error('[Socket] join_chat error:', err);
        socket.emit('chat_error', { message: 'Failed to join chat' });
      }
    });

    // ── Send Message ────────────────────────────────────────
    socket.on('send_message', async ({ jobId, receiverId, message }) => {
      try {
        if (!jobId || !receiverId || !message?.trim()) {
          socket.emit('chat_error', { message: 'jobId, receiverId and message are required' });
          return;
        }

        // Verify job access
        let job;
        if (socket.user.role === 'customer') {
          job = await Job.findOne({ _id: jobId, customer: socket.user._id });
        } else if (socket.user.role === 'provider') {
          job = await Job.findOne({ _id: jobId, provider: socket.provider._id });
        }

        if (!job) {
          socket.emit('chat_error', { message: 'Job not found or access denied' });
          return;
        }

        // Save to DB
        const newMsg = await Message.create({
          jobId,
          senderId: socket.user._id,
          senderRole: socket.user.role,
          receiverId,
          message: message.trim(),
          // If receiver is currently online in this room → auto mark as delivered
          isRead: false,
        });

        const msgPayload = {
          _id: newMsg._id,
          jobId,
          senderId: userId,
          senderRole: socket.user.role,
          receiverId,
          message: newMsg.message,
          isRead: false,
          createdAt: newMsg.createdAt,
        };

        const room = `chat_${jobId}`;

        // ── Emit to room (both parties) ─────────────────────
        io.to(room).emit('receive_message', msgPayload);

        // ── Single tick → sent ──────────────────────────────
        // Double tick → if receiver is online in this room
        const receiverOnline = isUserOnline(receiverId.toString());
        if (receiverOnline) {
          // Check if receiver is in this chat room
          const receiverInRoom = await isUserInRoom(io, room, receiverId.toString());
          if (receiverInRoom) {
            // Mark as read immediately + blue ticks
            await Message.findByIdAndUpdate(newMsg._id, { isRead: true, readAt: new Date() });
            io.to(room).emit('messages_read', { jobId, readBy: receiverId.toString() });
          } else {
            // Receiver online but in different screen → delivered (double tick)
            io.to(room).emit('message_delivered', { messageId: newMsg._id.toString(), jobId });
          }
        }

        // ── Push Notification (only if receiver NOT in this room) ──
        const receiverInRoom = await isUserInRoom(io, room, receiverId.toString());
        if (!receiverInRoom) {
          const senderName = socket.user.name;
          await createNotification({
            userId: receiverId,
            title: `New message from ${senderName}`,
            message: message.trim().length > 50
              ? message.trim().substring(0, 50) + '...'
              : message.trim(),
            type: 'job',
            referenceId: jobId,
            metadata: {
              screen: 'Chat',
              jobId: jobId.toString(),
              senderId: userId,
            },
          });
        }

      } catch (err) {
        console.error('[Socket] send_message error:', err);
        socket.emit('chat_error', { message: 'Failed to send message' });
      }
    });

    // ── Typing Indicator ────────────────────────────────────
    socket.on('typing_start', ({ jobId }) => {
      const room = `chat_${jobId}`;
      socket.to(room).emit('user_typing', {
        jobId,
        userId,
        name: socket.user.name,
      });
    });

    socket.on('typing_stop', ({ jobId }) => {
      const room = `chat_${jobId}`;
      socket.to(room).emit('user_stopped_typing', { jobId, userId });
    });

    // ── Mark Read (when user opens chat) ───────────────────
    socket.on('mark_read', async ({ jobId }) => {
      try {
        await Message.updateMany(
          { jobId, receiverId: socket.user._id, isRead: false },
          { isRead: true, readAt: new Date() }
        );

        const room = `chat_${jobId}`;
        io.to(room).emit('messages_read', { jobId, readBy: userId });
      } catch (err) {
        console.error('[Socket] mark_read error:', err);
      }
    });

    // ── Check Online Status ─────────────────────────────────
    socket.on('check_online', ({ userId: checkId }) => {
      socket.emit('online_status', {
        userId: checkId,
        isOnline: isUserOnline(checkId),
      });
    });

    // ── Disconnect ──────────────────────────────────────────
    socket.on('disconnect', () => {
      removeOnlineUser(userId, socket.id);
      console.log(`[Socket] Disconnected: ${socket.user.name} - ${socket.id}`);

      // Broadcast offline status
      socket.broadcast.emit('user_offline', { userId });
    });
  });
}

// ─────────────────────────────────────────────────────────────
// Helper: check if a userId is in a specific room
// ─────────────────────────────────────────────────────────────
async function isUserInRoom(io, room, userId) {
  try {
    const sockets = await io.in(room).fetchSockets();
    return sockets.some(s => s.user?._id?.toString() === userId);
  } catch {
    return false;
  }
}

export { isUserOnline };
